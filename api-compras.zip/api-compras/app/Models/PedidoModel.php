<?php

namespace App\Models;

use CodeIgniter\Model;

class PedidoModel extends Model
{
    protected $table      = 'pedidos';
    protected $primaryKey = 'id';
    protected $allowedFields = ['cliente_id', 'produto_id', 'status', 'quantidade', 'created_at', 'updated_at'];
    protected $useTimestamps = true;
}