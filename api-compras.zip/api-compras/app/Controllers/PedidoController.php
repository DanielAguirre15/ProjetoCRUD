<?php

/*namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;*/

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Models\PedidoModel;

/*class PedidoController extends BaseController*/
class PedidoController extends ResourceController
{
    protected $modelName = 'App\Models\PedidoModel';
    protected $format    = 'json';

    public function index()
    {
        return $this->respond([
            "cabecalho" => ["status" => 200, "mensagem" => "Lista de pedidos"],
            "retorno" => $this->model->findAll()
        ]);
    }

    public function show($id = null)
    {
        $pedidoModel = new PedidoModel();
        $pedido = $pedidoModel->find($id);

        if ($pedido) {
            return $this->respond([
                "cabecalho" => ["status" => 200, "mensagem" => "Pedido encontrado"],
                "retorno" => $pedido
            ]);
        }

        return $this->failNotFound('Pedido não encontrado.');
    }


    public function create()
    {
        $data = $this->request->getJSON(true); // Captura os dados JSON
        if (!$data) {
            return $this->fail('Dados inválidos.', 400);
        }

        $pedidoModel = new PedidoModel();

        if ($pedidoModel->insert($data)) {
            return $this->respondCreated([
                "cabecalho" => ["status" => 201, "mensagem" => "Pedido criado"],
                "retorno" => $data
            ]);
        }

        return $this->failValidationErrors($pedidoModel->errors());
    }


    public function update($id = null)
    {
        $data = $this->request->getJSON(true);
        if (!$data) {
            return $this->fail('Dados inválidos.', 400);
        }

        $pedidoModel = new PedidoModel();

        if ($pedidoModel->find($id)) {
            $pedidoModel->update($id, $data);
            return $this->respond([
                "cabecalho" => ["status" => 200, "mensagem" => "Pedido atualizado"],
                "retorno" => $data
            ]);
        }

        return $this->failNotFound('Pedido não encontrado.');
    }


    public function delete($id = null)
    {
        $pedidoModel = new PedidoModel();

        if ($pedidoModel->find($id)) {
            $pedidoModel->delete($id);
            return $this->respondDeleted([
                "cabecalho" => ["status" => 200, "mensagem" => "Pedido deletado"],
                "retorno" => ["id" => $id]
            ]);
        }

        return $this->failNotFound('Pedido não encontrado.');
    }

}
