<?php

/*namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;*/

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Models\ProdutoModel;

/*class ProdutoController extends BaseController*/
class ProdutoController extends ResourceController
{
    protected $modelName = 'App\Models\ProdutoModel';
    protected $format    = 'json';

    public function index()
    {
        return $this->respond([
            "cabecalho" => ["status" => 200, "mensagem" => "Lista de produtos"],
            "retorno" => $this->model->findAll()
        ]);
    }

    public function show($id = null)
    {
        $produtoModel = new ProdutoModel();
        $produto = $produtoModel->find($id);

        if ($produto) {
            return $this->respond([
                "cabecalho" => ["status" => 200, "mensagem" => "Produto encontrado"],
                "retorno" => $produto
            ]);
        }

        return $this->failNotFound('Produto não encontrado.');
    }


    public function create()
    {
        $data = $this->request->getJSON(true); // Captura os dados JSON
        if (!$data) {
            return $this->fail('Dados inválidos.', 400);
        }

        $produtoModel = new ProdutoModel();

        if ($produtoModel->insert($data)) {
            return $this->respondCreated([
                "cabecalho" => ["status" => 201, "mensagem" => "Produto criado"],
                "retorno" => $data
            ]);
        }

        return $this->failValidationErrors($produtoModel->errors());
    }


    public function update($id = null)
    {
        $data = $this->request->getJSON(true);
        if (!$data) {
            return $this->fail('Dados inválidos.', 400);
        }

        $produtoModel = new ProdutoModel();

        if ($produtoModel->find($id)) {
            $produtoModel->update($id, $data);
            return $this->respond([
                "cabecalho" => ["status" => 200, "mensagem" => "Produto atualizado"],
                "retorno" => $data
            ]);
        }

        return $this->failNotFound('Produto não encontrado.');
    }


    public function delete($id = null)
    {
        $produtoModel = new ProdutoModel();

        if ($produtoModel->find($id)) {
            $produtoModel->delete($id);
            return $this->respondDeleted([
                "cabecalho" => ["status" => 200, "mensagem" => "Produto deletado"],
                "retorno" => ["id" => $id]
            ]);
        }

        return $this->failNotFound('Produto não encontrado.');
    }

}
