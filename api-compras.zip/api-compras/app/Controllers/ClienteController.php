<?php

/*namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;*/

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Models\ClienteModel;

/*class ClienteController extends BaseController*/
class ClienteController extends ResourceController
{
    protected $modelName = 'App\Models\ClienteModel';
    protected $format    = 'json';

    public function index()
    {
        return $this->respond([
            "cabecalho" => ["status" => 200, "mensagem" => "Lista de clientes"],
            "retorno" => $this->model->findAll()
        ]);
    }

    public function show($id = null)
    {
        $clienteModel = new ClienteModel();
        $cliente = $clienteModel->find($id);

        if ($cliente) {
            return $this->respond([
                "cabecalho" => ["status" => 200, "mensagem" => "Cliente encontrado"],
                "retorno" => $cliente
            ]);
        }

        return $this->failNotFound('Cliente não encontrado.');
    }


    public function create()
    {
        $data = $this->request->getJSON(true); // Captura os dados JSON
        if (!$data) {
            return $this->fail('Dados inválidos.', 400);
        }

        $clienteModel = new ClienteModel();

        if ($clienteModel->insert($data)) {
            return $this->respondCreated([
                "cabecalho" => ["status" => 201, "mensagem" => "Cliente criado"],
                "retorno" => $data
            ]);
        }

        return $this->failValidationErrors($clienteModel->errors());
    }


    public function update($id = null)
    {
        $data = $this->request->getJSON(true);
        if (!$data) {
            return $this->fail('Dados inválidos.', 400);
        }

        $clienteModel = new ClienteModel();

        if ($clienteModel->find($id)) {
            $clienteModel->update($id, $data);
            return $this->respond([
                "cabecalho" => ["status" => 200, "mensagem" => "Cliente atualizado"],
                "retorno" => $data
            ]);
        }

        return $this->failNotFound('Cliente não encontrado.');
    }


    public function delete($id = null)
    {
        $clienteModel = new ClienteModel();

        if ($clienteModel->find($id)) {
            $clienteModel->delete($id);
            return $this->respondDeleted([
                "cabecalho" => ["status" => 200, "mensagem" => "Cliente deletado"],
                "retorno" => ["id" => $id]
            ]);
        }

        return $this->failNotFound('Cliente não encontrado.');
    }

}
