<?php


    use CodeIgniter\Router\RouteCollection;

    $routes->get('/', 'Home::index');
    
    /*$routes->group('api', function ($routes) {
        $routes->get('clientes', 'ClienteController::index');
        $routes->get('produtos', 'ProdutoController::index');
        $routes->get('pedidos', 'PedidoController::index');
    });*/
    
    $routes->group('api', function ($routes) {
        // Clientes
        $routes->get('clientes', 'ClienteController::index');      // Listar todos
        $routes->get('clientes/(:num)', 'ClienteController::show/$1'); // Buscar um por ID
        $routes->post('clientes', 'ClienteController::create');    // Criar novo
        $routes->put('clientes/(:num)', 'ClienteController::update/$1'); // Atualizar
        $routes->delete('clientes/(:num)', 'ClienteController::delete/$1'); // Deletar

        // Produtos
        $routes->get('produtos', 'ProdutoController::index');
        $routes->get('produtos/(:num)', 'ProdutoController::show/$1');
        $routes->post('produtos', 'ProdutoController::create');
        $routes->put('produtos/(:num)', 'ProdutoController::update/$1');
        $routes->delete('produtos/(:num)', 'ProdutoController::delete/$1');

        // Pedidos
        $routes->get('pedidos', 'PedidoController::index');
        $routes->get('pedidos/(:num)', 'PedidoController::show/$1');
        $routes->post('pedidos', 'PedidoController::create');
        $routes->put('pedidos/(:num)', 'PedidoController::update/$1');
        $routes->delete('pedidos/(:num)', 'PedidoController::delete/$1');
    });
    
    /**
     * @var RouteCollection $routes
    */
